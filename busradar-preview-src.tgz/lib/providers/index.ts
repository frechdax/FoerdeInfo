import { FlensburgLiveProvider } from "@/lib/providers/flensburg-live";
import { NahSHRealtimeProvider } from "@/lib/providers/nahsh-realtime";
import { SiriEtProvider } from "@/lib/providers/siri-et";
import { getRegionData } from "@/lib/gtfs/store";
import type { ProviderStatus, Vehicle } from "@/lib/types";

const realtime = new NahSHRealtimeProvider();
const flensburg = new FlensburgLiveProvider();
const siriEt = new SiriEtProvider();

export async function getVehicles(): Promise<Vehicle[]> {
  const batches = await Promise.allSettled([flensburg.getVehicles(), realtime.getVehicles(), siriEt.getVehicles()]);
  const all = batches.flatMap((r) => r.status === "fulfilled" ? r.value : []);
  const byTrip = new Map<string, Vehicle>();
  for (const vehicle of all) {
    const key = vehicle.tripId || vehicle.id;
    const existing = byTrip.get(key);
    if (!existing || (vehicle.accuracyType === "gps" && existing.accuracyType !== "gps")) byTrip.set(key, vehicle);
  }
  return [...byTrip.values()];
}

export async function getProviderStatuses(): Promise<ProviderStatus[]> {
  const data = getRegionData();
  const staticStatus: ProviderStatus = data.trips.length
    ? { id: "static-gtfs", name: "Regionale GTFS-Fahrplandaten", state: "online", lastUpdate: data.generatedAt || undefined, detail: `${data.routes.length} Linien · ${data.stops.length} Haltestellen · ${data.trips.length} Fahrten · ${Object.keys(data.shapes).length} Shapes` }
    : { id: "static-gtfs", name: "Regionale GTFS-Fahrplandaten", state: "disabled", detail: "Noch nicht importiert. `npm run gtfs:import` ausführen." };
  const statuses = await Promise.all([realtime.getProviderStatus(), siriEt.getProviderStatus(), flensburg.getProviderStatus()]);
  return [staticStatus, ...statuses];
}
